package com.example.todolist

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.DialogFragment
import com.example.a2.R

class AddTaskDialogFragment : DialogFragment() {

    private lateinit var taskNameEditText: EditText
    private lateinit var saveTaskButton: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.dialog_add_task, container, false)
        taskNameEditText = view.findViewById(R.id.task_name_edit_text)
        saveTaskButton = view.findViewById(R.id.save_task_button)
        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        saveTaskButton.setOnClickListener {
            val taskName = taskNameEditText.text.toString()
            (targetFragment as? TaskListFragment)?.addTask(taskName)
            dismiss()
        }
    }
}
